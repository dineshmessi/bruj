<?php require'header.php';?>    
    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">Project</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Project  <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>

   

    <section class="ftco-section bg-light">
      <div class="container">
        <div class="row">
          <div class="col-md-4 ftco-animate">
            <div class="service-entry">
              <a href="service1.html" class="block-20" style="background-image: url('images/image_1.jpg');">
                <div class="meta-date text-center p-2">
                  <span class="day">07</span>
                  <span class="mos">February</span>
                  <span class="yr">2019</span>
                </div>
              </a>
              <div class="text pt-4">
                <h3 class="heading"><a href="#">Apartments</a></h3>
              <!--  <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>--->
                <div class="d-flex align-items-center mt-4">
                  <p class="mb-0"><a href="service1.html" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                  <p class="ml-auto mb-0">
                    <!--<a href="#" class="mr-2">Admin</a>--->
                    <!--<a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a>--->
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="service-entry">
              <a href="service2.html" class="block-20" style="background-image: url('images/image_4.jpg');">
                <div class="meta-date text-center p-2">
                  <span class="day">07</span>
                  <span class="mos">February</span>
                  <span class="yr">2019</span>
                </div>
              </a>
              <div class="text pt-4">
                <h3 class="heading"><a href="#">Kolkata</a></h3>
                <!---<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>--->
                <div class="d-flex align-items-center mt-4">
                  <p class="mb-0"><a href="service2.html" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                  <p class="ml-auto mb-0">
                    <!-- <a href="#" class="mr-2">Admin</a>--->
                    <!--<a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a>--->
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="service-entry">
              <a href="service3.html" class="block-20" style="background-image: url('images/bangalore.jpg');">
                <div class="meta-date text-center p-2">
                  <span class="day">07</span>
                  <span class="mos">February</span>
                  <span class="yr">2019</span>
                </div>
              </a>
              <div class="text pt-4">
                <h3 class="heading"><a href="#">Bangalore</a></h3>
                <!--<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>--->
                <div class="d-flex align-items-center mt-4">
                  <p class="mb-0"><a href="service3.html" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                  <p class="ml-auto mb-0">
                    <!--<a href="#" class="mr-2">Admin</a>--->
                    <!--<a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a>--->
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="service-entry">
              <a href="service4.html" class="block-20" style="background-image: url('images/image_5.jpg');">
                <div class="meta-date text-center p-2">
                  <span class="day">07</span>
                  <span class="mos">February</span>
                  <span class="yr">2019</span>
                </div>
              </a>
              <div class="text pt-4">
                <h3 class="heading"><a href="#">Chennai</a></h3>
                <!--<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>--->
                <div class="d-flex align-items-center mt-4">
                  <p class="mb-0"><a href="service4.html" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                  <p class="ml-auto mb-0">
                    <!--<a href="#" class="mr-2">Admin</a>--->
                    <!--<a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a>--->
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="service-entry">
              <a href="service5.html" class="block-20" style="background-image: url('images/decor.jpg');">
                <div class="meta-date text-center p-2">
                  <span class="day">07</span>
                  <span class="mos">February</span>
                  <span class="yr">2019</span>
                </div>
              </a>
              <div class="text pt-4">
                <h3 class="heading"><a href="#">Interior designs</a></h3>
                <!--<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>--->
                <div class="d-flex align-items-center mt-4">
                  <p class="mb-0"><a href="service5.html" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                  <p class="ml-auto mb-0">
                    <!--<a href="#" class="mr-2">Admin</a>--->
                    <!--<a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a>--->
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="service-entry">
              <a href="service6.html" class="block-20" style="background-image: url('images/decor1.jpg');">
                <div class="meta-date text-center p-2">
                  <span class="day">07</span>
                  <span class="mos">February</span>
                  <span class="yr">2019</span>
                </div>
              </a>
              <div class="text pt-4">
                <h3 class="heading"><a href="#">Interior designs</a></h3>
              <!--  <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>--->
                <div class="d-flex align-items-center mt-4">
                  <p class="mb-0"><a href="service6.html" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                  <p class="ml-auto mb-0">
                    <!--<a href="#" class="mr-2">Admin</a>--->
                    <!--<a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a>--->
                  </p>
                </div>
              </div>
            </div>
          </div>

<!--
    </section></div></div></section></div></section>---></div></div></section>
 <?php require'footer.php';?>
  </body>
</html>