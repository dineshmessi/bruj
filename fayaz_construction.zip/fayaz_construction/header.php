 
  <!DOCTYPE html>
<html lang="en">
  <head>
    <title>Fayaz-construction</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="/css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">
	

    <link rel="stylesheet" href="css/ionicons.min.css">
	

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
  <style>
  .navbar-brand{
  background-color:white;}
  </style>
<!-- ================Offcanvus Menu Area =================-->
	<div class="side_menu">
			<ul class="list menu_right" style="margin-left:-20px;">
				<li>
					<a href="index.php">Home</a>
				</li>
				<li>
					<a href="about.php">About</a>
				</li>
				<li>
					<a href="project.php">Projects</a>
				</li>
				
			
				<li>
					<a href="contact.php">Contact</a>
				</li>
				<br><br>
					<a href="contact.html"><span>youremail@email.com</span></a><br><br>
				
				
					<a href="contact.html"><span>Call Us: + 1235 2355 98</span></a>
				
				
			</ul>
	</div>
	<!--================End Offcanvus Menu Area =================-->

	<!--================Canvus Menu Area =================-->
	<div class="canvus_menu">
		<div class="container">
			<div class="float-right">
				<div class="toggle_icon" title="Menu Bar">
					<span></span>
				</div>
			</div>
		</div>
	</div>
	<!--================End Canvus Menu Area =================-->
	
	
	<!--================Logo =================-->

  <a class="navbar-brand" href="index.html">
        <img src="images/logof.png"  style="width:100%; "alt="logo">
      </a>
    
	<!--================End Logo =================-->