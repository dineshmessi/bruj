

<?php include "header.php" ?>

  <section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">Contact us</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Contact<i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>

	<!--================End Logo =================-->
    <!-- END nav -->
	<!--<div class="form-all">
		    				<div class="form-group">
		    					<input type="text" class="form-control" placeholder="First Name">
		    				</div>
		    				<div class="form-group">
		    					<input type="text" class="form-control" placeholder="Last Name">
		    				</div>
	    					
	    					<div class="form-group">
		    					<input type="text" class="form-control" placeholder="Phone">
		    				</div>
	    					<div class="form-group">
		              <textarea name="message" id="" cols="30" rows="2" class="form-control" placeholder="type your message"></textarea>
		            </div>
		            <div class="form-group">
		              <input type="submit" value="contact us" class="btn btn-primary py-3 px-4">
		            </div>
					</div>
					<style>

body {
margin:0;
padding:0;
}
.container {
width:1200px !important;
padding:0 !important;
}
.header {
background:url(images/topinnerbg.png);
background-size:cover;
position:static !important;
min-height:432px;
margin:0 !important;
padding:0 !important;
}

.navbar {
background:none !important;
border:none !important;
}
.toplink:hover {
    color:#f2f2f2 !important;
background:none !important;
border:none !important;
}
li {
list-style:none;
}-->
	</style>
		
	
	<div class="hdcont"> 
	
	

<!--<h3>Support<p>Contact Us</p></h3>-->

<style type="text/css">
/*----------Text Styles----------*/
.ws6 {font-size: 8px;}
.ws7 {font-size: 9.3px;}
.ws8 {font-size: 11px;}
.ws9 {font-size: 12px;}
.ws10 {font-size: 13px;}
.ws11 {font-size: 15px;}
.ws12 {font-size: 16px;}
.ws14 {font-size: 14px;}
.ws15 {font-size: 14px;}
.ws16 {font-size: 16px;}
.ws18 {font-size: 18px;}
.ws20 {font-size: 27px;}
.ws22 {font-size: 29px;}
.ws24 {font-size: 32px;}
.ws26 {font-size: 35px;}
.ws28 {font-size: 37px;}
.ws36 {font-size: 34px;}
.ws48 {font-size: 64px;}
.ws72 {font-size: 96px;}
.wpmd {font-size: 14px;}
/*----------Para Styles----------*/
DIV,UL,OL /* Left */
{
 margin-top: 0px;
 margin-bottom: 0px;
}
div#containersup
{
	
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
margin-top:50px;

font-family: Poppins;
}
#image1 button
{

margin-top:20;

color: #4F4F4F;
background: #EACD69;
border-radius: 2.75px;
width: 150px;
height: 42px;
margin-left:480px;
border:none;
font-weight: 500;
}
#image1 input
{
height:50;
width:630;
}

.f1md{
border-bottom:4px solid;
color:#FF8C1F;
font-size:34px;



color:gray;
width:190px;
margin:10px auto 10px auto;

}

    

 .f1md p {
display:block;
color:#FF8C1F;


margin-bottom:-10px;}

.f2md{
display:block;
margin-bottom:60px;
margin-top:50px;}

 .sbbtn{
outline:none;
border:none;
margin-top:20px;
margin-bottom:40px;
padding:6px 50px;
background-color:#FF9F44}




.etems{
margin-top:40px !important;}
.etems  label{
font-size:18px;
font-weight:600;
color:#ff9f44;
}

.form_cont{
	margin-bottom: 100px;
}





.fr1 input{
border:none;
outline:none;
border:2px solid;
border-color:gray;
margin-top:20px ;
width:100%;
padding:10px 10px
 }
 textarea{
margin-top:30px !important;
width:100%;

border:2px solid;
border-color:gray;
padding:10px 10px;}
.sub_head{
font-size:28px;
margin-top:-20px;
margin-bottom: 30px;
color:#FF9F44;
}
.ptagin{
 text-align:justify; 
                text-justify:auto;
font-size:16px;
color:gray;
}
.in_det{
margin-top:200px !important;}
.text3{
margin-bottom:100px;}






</style>
<body> 

<div id="containersup">

<div id="text1 text-center align-items-center justify-content-center" >
<div class="wpmd text-center">

</div></div>


<div class="f2md text-center"><p >If you want to contact with our faculties fill the below details </p></div>

<div  class="form_cont">
	<div class="container text-center">
		<div class="row"><div class="col-lg-6 text-center">
			<div id="image1 text-center" >


<script language=javascript>
	function checkform() {  if (document.mainform.name.value == '') {    alert("Please type your full name!");    document.mainform.name.focus();    return false;  }  if (document.mainform.email.value == '') {    alert("Please enter your e-mail address!");    document.mainform.email.focus();    return false;  } if (document.mainform.message.value == '') {    alert("Please type your message!");    document.mainform.message.focus();    return false;  }  return true;}		</script>

<form method=post name=mainform onsubmit="return checkform()"><input type="hidden" name="form_id" value="15712278023737"><input type="hidden" name="form_token" value="9f1b11a1ca6995e6b1492b7869927c17">
<input type=hidden name=a value=support>
<input type=hidden name=action value=send>
<div class="fr1 text-center">
		<input placeholder="Your Name" type="text" name="name" value="" size=30 class=inpts></div>

		<div class="fr1">
<input placeholder="last Name" type="text" name="name" value="" size=30 class=inpts></div>	


	<div class="fr1">
	<input placeholder="mobile number" type="text" name="name" value="" size=30 class=inpts></div>

				<div class="fr1">
<input placeholder="Your Email" type="email" name="email" value="" size=30 class=inpts></div>
		<div class="fr1">
	
	<textarea name=message placeholder="leave your message......." class=inpts cols=45 rows=4></textarea></div>
		
<button class="sbbtn" type=submit value="Send" >Send</button>
</form>
</div>
			



		</div>
			<div class="col-lg-6 text-center">
<div id="text3" >
<div class="wpmd justify-content-center">
<div class="sub_head justify-content-center"><span>Main office</span></div>
<div class="justify-content-center ptagin">The openness always and in everything means about close interaction with each our customer if it is demanded by the developing circumstances of business interaction. Therefore in our life all business aspects are arranged simply, openly and reliably like our office. Trust and mutual aid  a basis of aspiration of Golden group to providing the best services in that area of business activity.</div>
</div></div>


<div id="text4 in_det">
<div class="etems text-left">
	<p><label>Number</label> : &nbsp;&nbsp;044-16w562677</p>

<p><label>E-mail :</label> &nbsp;&nbsp;

admin@Burajconstructions.io</p>


<p><label>contact :</label> &nbsp;&nbsp;		 @Burajconstructions</p></div>
</div></div></div></div></div></div></body>
<!--<div id="image5" style="position:absolute; overflow:hidden; left:22px; top:816px; width:1151px; height:321px; z-index:10; "><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2482.978813840034!2d-0.07833678434270301!3d51.513604679636195!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4876034b608868ad%3A0xb4b96148789b6ed2!2s84%20Aldgate%20High%20St%2C%20London%20EC3N%201LH%2C%20UK!5e0!3m2!1sen!2sin!4v1570172324780!5m2!1sen!2sin" width="100%" height="100%" frameborder="0" style="border:0;" allowfullscreen=""></iframe></div>

</div>
	
	
		
		--->
					
						
						
<?php include "footer.php" ?>